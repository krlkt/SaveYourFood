package com.example.saveyourfood;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

import com.example.saveyourfood.models.MyGrocery;

import java.util.Date;

public class GroceryListActivity extends AppCompatActivity {

    private static final String TAG = "GroceryListActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grocery_list);

        MyGrocery grocery = new MyGrocery("apple", 2.0, "kg", "08.11.2020" );

        Log.d(TAG, "onCreate: my Grocery: " + grocery.toString());
    }
}