package com.example.saveyourfood.models;

import java.util.Date;

public class MyGrocery {
    private String name;
    private double quantity;
    private String unit;
    private String date;

    public MyGrocery(String name, double quantity, String unit, String date) {
        this.name = name;
        this.quantity = quantity;
        this.unit = unit;
        this.date = date;
    }

    public MyGrocery() {

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getQuantity() {
        return quantity;
    }

    public void setQuantity(double quantity) {
        this.quantity = quantity;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    @Override
    public String toString() {
        return "MyGrocery{" +
                "name='" + name + '\'' +
                ", quantity=" + quantity +
                ", unit='" + unit + '\'' +
                ", date=" + date +
                '}';
    }
}
